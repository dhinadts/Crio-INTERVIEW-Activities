/* import { Box, Typography, Container, Stack } from "@mui/material";
import HospitalCard from "../../components/HospitalCard/HospitalCard";
import { useEffect, useState } from "react";
// import cta from "../../assets/cta.png";
import SearchBar from "../../components/SearchBar/SearchBar";
import NavBar from "../../components/Navbar/Navbar";


let cta = "";
export default function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const [filteredBookings, setFilteredBookings] = useState([]);

  useEffect(() => {
    const localBookings = localStorage.getItem("bookings") || "[]";
    setBookings(JSON.parse(localBookings));
  }, []);

  useEffect(() => {
    setFilteredBookings(bookings);
  }, [bookings]);

  return (
    <>
      <NavBar />
      <Box
        sx={{ background: "linear-gradient(#EFF5FE, rgba(241,247,255,0.47))" }}
      >
        <Box
          mb="50px"
          pt={{ xs: 3, md: 1 }}
          sx={{
            position: "relative",
            background: "linear-gradient(90deg, #2AA7FF, #0C8CE5)",
            borderBottomLeftRadius: "1rem",
            borderBottomRightRadius: "1rem",
          }}
        >
          <Container maxWidth="xl" sx={{ px: { xs: 0, md: 5 } }}>
            <Stack
              direction={{ xs: "column", md: "row" }}
              spacing={{ xs: 0, md: 12 }}
              alignItems={{ xs: "center", md: "flex-end" }}
            >
              <Typography
                component="h1"
                pb={1}
                fontSize={{ xs: 32, md: 40 }}
                fontWeight={700}
                color="#fff"
              >
                My Bookings
              </Typography>
              <Box
                bgcolor="#fff"
                p={3}
                flexGrow={1}
                borderRadius={2}
                boxShadow="0 0 10px rgba(0,0,0,0.1)"
                sx={{ translate: "0 50px" }}
                width={{ xs: 1, md: "auto" }}
              >
                <SearchBar list={bookings} filterList={setFilteredBookings} />
              </Box>
            </Stack>
          </Container>
        </Box>

        <Container maxWidth="xl" sx={{ pt: 8, pb: 10, px: { xs: 0, md: 4 } }}>
          <Stack alignItems="flex-start" direction={{ md: "row" }}>
            <Stack
              mb={{ xs: 4, md: 0 }}
              spacing={3}
              width={{ xs: 1, md: "calc(100% - 384px)" }}
              mr="24px"
            >
              {filteredBookings.length > 0 &&
                filteredBookings.map((hospital) => (
                  <HospitalCard
                    key={hospital["Hospital Name"]}
                    details={hospital}
                    booking={true}
                  />
                ))}

              {filteredBookings.length == 0 && (
                <Typography variant="h3" bgcolor="#fff" p={3} borderRadius={2}>
                  No Bookings Found!
                </Typography>
              )}
            </Stack>

            <img src={cta} width={360} height="auto" />
          </Stack>
        </Container>
      </Box>
    </>
  );
}
 */


import { Container, Typography, Box, Card, CardContent, Stack, Button } from "@mui/material";
import { useEffect, useState } from "react";
import NavBar from "../../components/Navbar/Navbar";
import DeleteIcon from "@mui/icons-material/Delete";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import EmailIcon from "@mui/icons-material/Email";

export default function MyBookings() {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    // Load bookings from localStorage
    const savedBookings = localStorage.getItem("bookings");
    if (savedBookings) {
      setBookings(JSON.parse(savedBookings));
    }
  }, []);

  const handleDeleteBooking = (index) => {
    const updatedBookings = bookings.filter((_, i) => i !== index);
    setBookings(updatedBookings);
    localStorage.setItem("bookings", JSON.stringify(updatedBookings));
  };

  const handleClearAll = () => {
    setBookings([]);
    localStorage.removeItem("bookings");
  };

  return (
    <>
      <NavBar />
      <Container maxWidth="xl" sx={{ py: 8 }}>
        {/* Header */}
        <Box sx={{ mb: 6 }}>
          <Typography variant="h1" fontSize={32} fontWeight={600} mb={2}>
            My Bookings
          </Typography>
          <Typography color="text.secondary">
            View and manage all your event bookings
          </Typography>
        </Box>

        {/* Bookings List */}
        {bookings.length === 0 ? (
          <Box textAlign="center" py={10}>
            <Typography variant="h6" color="text.secondary" mb={2}>
              No bookings yet
            </Typography>
            <Typography color="text.secondary">
              Book your first event to see it here!
            </Typography>
          </Box>
        ) : (
          <>
            <Stack spacing={3} mb={4}>
              {bookings.map((booking, index) => (
                <Card key={index} sx={{ borderRadius: 2, boxShadow: 2 }}>
                  <CardContent>
                    <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" alignItems="flex-start">
                      <Box flex={1}>
                        <Typography variant="h3" fontSize={24} fontWeight={600} mb={2}>
                          {booking.eventName}
                        </Typography>
                        
                        <Stack spacing={1}>
                          <Stack direction="row" alignItems="center" spacing={1}>
                            <LocationOnIcon fontSize="small" color="action" />
                            <Typography>{booking.address}</Typography>
                          </Stack>
                          
                          <Stack direction="row" alignItems="center" spacing={1}>
                            <CalendarTodayIcon fontSize="small" color="action" />
                            <Typography>
                              {new Date(booking.bookingDate).toLocaleDateString()}
                            </Typography>
                          </Stack>
                          
                          <Stack direction="row" alignItems="center" spacing={1}>
                            <AccessTimeIcon fontSize="small" color="action" />
                            <Typography>{booking.bookingTime}</Typography>
                          </Stack>
                          
                          <Stack direction="row" alignItems="center" spacing={1}>
                            <EmailIcon fontSize="small" color="action" />
                            <Typography>{booking.bookingEmail}</Typography>
                          </Stack>
                        </Stack>
                      </Box>
                      
                      <Button
                        startIcon={<DeleteIcon />}
                        color="error"
                        onClick={() => handleDeleteBooking(index)}
                        sx={{ mt: { xs: 2, md: 0 } }}
                      >
                        Cancel
                      </Button>
                    </Stack>
                  </CardContent>
                </Card>
              ))}
            </Stack>
            
            <Box textAlign="right">
              <Button
                variant="outlined"
                color="error"
                onClick={handleClearAll}
              >
                Clear All Bookings
              </Button>
            </Box>
          </>
        )}
      </Container>
    </>
  );
}